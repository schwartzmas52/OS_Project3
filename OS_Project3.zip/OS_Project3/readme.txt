javac WebBrowser.java			//compile the program
java WebBrowser <website url>		//run the program